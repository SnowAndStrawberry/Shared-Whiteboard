
public class SuccessfulCheck {
	public static String errorDescription;
	public static boolean isSuccessful;

	public SuccessfulCheck() {
		this.errorDescription = null;
		this.isSuccessful = false;
	}
}